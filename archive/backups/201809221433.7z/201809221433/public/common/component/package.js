import { Component } from "./Component.js";
import { Name } from "./Name.js";
import { Health } from "./Health.js";

export default {
	Component,
	Name,
	Health
}