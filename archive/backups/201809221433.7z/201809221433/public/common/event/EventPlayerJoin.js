import EnumMessageType from "./../enum/MessageType.js";
import EnumEventType from "./../enum/EventType.js";

import { Event } from "./Event.js";

class EventPlayerJoin extends Event {
	constructor(username) {
		super(
			EnumMessageType.PLAYER,
			EnumEventType.PLAYER_JOIN,
			{
				Username: username
			}
		);

		super.PostInit(this, arguments);
	}
}

export { EventPlayerJoin };