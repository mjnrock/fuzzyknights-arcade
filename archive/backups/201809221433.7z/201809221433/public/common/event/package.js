import { EventData } from "./EventData.js";

export default {
	EventData
};