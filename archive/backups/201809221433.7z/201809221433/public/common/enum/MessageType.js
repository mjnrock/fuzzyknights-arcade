export default {
	PLAYER: 		1
};