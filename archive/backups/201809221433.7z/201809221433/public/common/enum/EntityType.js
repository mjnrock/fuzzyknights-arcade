export default {
	ENTITY:			1,
	ENTITY_CAT:		2
}