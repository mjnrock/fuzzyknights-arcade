export default {
	PLAYER_JOIN:				1
};