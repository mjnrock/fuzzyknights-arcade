export default {
	NAME: 		1,
	HEALTH:		2
};