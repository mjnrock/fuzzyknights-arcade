export default {
	SERVER:			1,
	CLIENT:			2,
	BROADCAST:		3
}