export default {
	VOID:		1,
	GRASS:		2,
	WATER:		3,
	DIRT:		4,
	SAND:		5,
	STONE:		6
};