import { Handler } from "./Handler.js";
import { EntityHandler } from "./EntityHandler.js";

export default {
	Handler,	
	EntityHandler
};