import EntityManager from "./EntityManager.js";

import { Entity } from "./Entity.js";
import { EntityCat } from "./EntityCat.js";

export default {	
	Entity,
	EntityCat,

	EntityManager
}