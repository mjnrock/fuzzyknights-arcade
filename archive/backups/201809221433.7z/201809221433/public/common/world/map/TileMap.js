class TileMap {

}

export { TileMap };