class Coordinate {
	constructor(x, y, z) {
		this.X = x;
		this.Y = y;
		this.Z = z;
	}
}

export { Coordinate };