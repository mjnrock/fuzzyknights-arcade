import KeyHandler from "./KeyHandler.js";

export default {
	KeyHandler
};