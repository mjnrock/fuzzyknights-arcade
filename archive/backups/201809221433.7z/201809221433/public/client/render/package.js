import Camera from "./Camera.js";

export default {
	Camera
};