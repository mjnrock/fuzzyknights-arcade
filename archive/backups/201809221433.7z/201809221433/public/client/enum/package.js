import PlayerKeyState from "./PlayerKeyState.js";

export default {
	PlayerKeyState
};