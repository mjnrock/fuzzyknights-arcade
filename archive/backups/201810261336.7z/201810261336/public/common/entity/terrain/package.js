import { Terrain } from "./Terrain.js";

export default {
	Terrain
};