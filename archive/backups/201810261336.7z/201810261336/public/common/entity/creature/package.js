import { Creature } from "./Creature.js";

export default {
	Creature
};