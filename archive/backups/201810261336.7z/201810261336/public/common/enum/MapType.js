export default {
	VOXEL:		1,
	TERRAIN:	2,
	BIOME:		3
};