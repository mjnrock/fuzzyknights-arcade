export default {
	INPUT_KEYBOARD:			1,

	ENTITY_DAMAGE:			2
};