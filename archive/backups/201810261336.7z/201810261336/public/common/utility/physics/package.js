import Planar from "./2D.js";
import Cubic from "./3D.js";

export default {
	Planar,
	Cubic
};