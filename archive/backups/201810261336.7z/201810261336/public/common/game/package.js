import GameLoop from "./GameLoop.js";

import { Player } from "./Player.js";

export default {
	GameLoop,

	Player
};