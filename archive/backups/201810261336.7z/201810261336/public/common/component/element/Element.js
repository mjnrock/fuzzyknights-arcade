class Element {
	constructor(type) {
		this.Type = type;
	}

	GetType() {
		return this.Type;
	}
}

export { Element };