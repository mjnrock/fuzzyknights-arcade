import { Mutator } from "./Mutator.js";
import { Resources } from "./Resources.js";
import { Attributes } from "./Attributes.js";

export default {
	Mutator,
	Resources,
	Attributes
};