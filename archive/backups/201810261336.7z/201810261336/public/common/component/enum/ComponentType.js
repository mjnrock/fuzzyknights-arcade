export default {
	RIGID_BODY:			1,
	COMPOUND_ENTITY:	2,

	RESOURCES:			10,
	ATTRIBUTES:			11
};