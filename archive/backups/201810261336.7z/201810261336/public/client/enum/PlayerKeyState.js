export default {
	IDLE:		1 << 0,
	LEFT:		1 << 1,
	RIGHT:		1 << 2,
	UP:			1 << 3,
	DOWN:		1 << 4
};